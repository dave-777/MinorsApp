import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      // Application name
      title: 'Flutter Stateful Clicker Counter',
      theme: ThemeData(
        // Application theme data, you can set the colors for the application as
        // you want
        primarySwatch: Colors.grey,
      ),
      home: MyHomePage(title: 'Flutter Demo Clicker Counter Home Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  final String title;
  const MyHomePage({Key? key, required this.title}) : super(key: key);

  // This widget is the home page of your application. It is stateful, meaning
  // that it has a State object (defined below) that contains fields that affect
  // how it looks.

  // This class is the configuration for the state. It holds the values (in this
  // case the title) provided by the parent (in this case the App widget) and
  // used by the build method of the State. Fields in a Widget subclass are
  // always marked "final".

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    double widthSize = MediaQuery.of(context).size.width;
    double heightSize = MediaQuery.of(context).size.height;

    return Scaffold(
      backgroundColor: Color(0xf2f6f4f4),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: CustomScrollView(
          slivers: [
            SliverAppBar(
              pinned: true,
              backgroundColor: Color(0xffffffff),
              leadingWidth: 72,
              leading: Padding(
                padding: const EdgeInsets.only(left: 0.8),
                child: Icon(
                  Icons.person,
                  color: Colors.black,
                  size: 30.0,
                ),
              ),
            ),
            SliverToBoxAdapter(
              child: Container(
                width: widthSize,
                child: Column(

                    // fit: StackFit.passthrough,
                    //alignment: Alignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      // Icon(Icons.bar_chart_rounded),

                      Container(
                        // height: 77,
                        padding: EdgeInsets.only(top: 25.2, left: 0, right: 10),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Stack(
                              children: [
                                Container(
                                    width: widthSize - 37,
                                    height: 82,
                                    padding: EdgeInsets.only(top: 10),
                                    margin: EdgeInsets.only(top: 50),
                                    decoration: BoxDecoration(
                                        color: Colors.white,
                                        border: Border.all(
                                          color: Colors.green,
                                          width: 0.7,
                                        ),
                                        borderRadius: BorderRadius.only(
                                          topRight: Radius.circular(13),
                                          topLeft: Radius.circular(13),
                                        ) //                 <--- border radius here
                                        ),

                                    //width: widthSize,
                                    child: Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text("عدد بلاغات المفقودات"),
                                          Text("0",
                                              style: TextStyle(
                                                  fontSize: 22,
                                                  fontWeight: FontWeight.bold)),
                                        ],
                                      ),
                                    )),
                                Positioned(
                                  // right: 77,
                                  bottom: 52,
                                  left: 227,
                                  //  width: 77,
                                  // height: 77,
                                  child: Container(
                                    decoration: BoxDecoration(
                                        //color: Color(0xff000000),
                                        gradient: LinearGradient(
                                          begin: Alignment.topRight,
                                          end: Alignment.bottomLeft,
                                          colors: [
                                            Color(0xff10240b),
                                            Color(0xff000000),
                                          ],
                                        ),
                                        border: Border.all(
                                          color: Colors.red,
                                          width: 0.7,
                                        ),
                                        borderRadius: BorderRadius.only(
                                          topRight: Radius.circular(27),
                                          topLeft: Radius.circular(27),
                                          bottomLeft: Radius.circular(27),
                                          bottomRight: Radius.circular(27),
                                        ),
                                        boxShadow: [
                                          BoxShadow(
                                              color: Colors.grey.shade600,
                                              spreadRadius: 1,
                                              blurRadius: 15)
                                        ] //                 <--- border radius here
                                        ),
                                    // color: Color(0xffa48482),
                                    child: Container(
                                        width: 77,
                                        height: 77,
                                        child: Icon(
                                          Icons.bar_chart,
                                          size: 37,
                                          color: Colors.white,
                                        )),

                                    //Image.asset("images/ana.JPG")),
                                    //Icon(Icons.analytics,
                                    //  size: 75, color: Colors.white),
                                  ),
                                ),
                              ], // Stack Children ends here
                            ),
                          ],
                        ),
                      ),
                      // above is the end of the first image row container
                      // above is the end of the first image row container
                      //

                      // above is the end of the first image row container
                      // above is the end of the first image row container

                      Container(
                        // height: 77,
                        padding: EdgeInsets.only(top: 25.2, left: 0, right: 10),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Stack(
                              children: [
                                Container(
                                    width: widthSize - 37,
                                    height: 82,
                                    padding: EdgeInsets.only(top: 10),
                                    margin: EdgeInsets.only(top: 50),
                                    decoration: BoxDecoration(
                                        color: Colors.white,
                                        border: Border.all(
                                          color: Colors.green,
                                          width: 0.7,
                                        ),
                                        borderRadius: BorderRadius.only(
                                          topRight: Radius.circular(13),
                                          topLeft: Radius.circular(13),
                                        ) //                 <--- border radius here
                                        ),

                                    //width: widthSize,
                                    child: Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text("اجمالي الحوالات"),
                                          Text("ر.س 0",
                                              style: TextStyle(
                                                  fontSize: 22,
                                                  fontWeight: FontWeight.bold)),
                                        ],
                                      ),
                                    )),
                                Positioned(
                                  // right: 77,
                                  bottom: 52,
                                  left: 227,
                                  //  width: 77,
                                  // height: 77,
                                  child: Container(
                                    decoration: BoxDecoration(
                                        gradient: LinearGradient(
                                          begin: Alignment.topRight,
                                          end: Alignment.bottomLeft,
                                          colors: [
                                            Color(0xff047e45),
                                            Color(0xff0ab271),
                                          ],
                                        ),
                                        //color: Color(0xff04863e),

                                        border: Border.all(
                                          color: Colors.green,
                                          width: 0.7,
                                        ),
                                        borderRadius: BorderRadius.only(
                                          topRight: Radius.circular(27),
                                          topLeft: Radius.circular(27),
                                          bottomLeft: Radius.circular(27),
                                          bottomRight: Radius.circular(27),
                                        ),
                                        boxShadow: [
                                          BoxShadow(
                                              color: Colors.grey.shade600,
                                              spreadRadius: 1,
                                              blurRadius: 15)
                                        ] //                 <--- border radius here
                                        ),
                                    // color: Color(0xffa48482),
                                    child: Container(
                                        width: 77,
                                        height: 77,
                                        child: Icon(
                                          Icons.bar_chart,
                                          size: 37,
                                          color: Colors.white,
                                        )),
                                    //   Image.asset("images/greenAna.JPG")),
                                    //Icon(Icons.analytics,
                                    //  size: 75, color: Colors.white),
                                  ),
                                ),
                              ], // Stack Children ends here
                            ),
                          ],
                        ),
                      ),
                      // above is the end of the 2nd image row container
                      // above is the end of the 2nd image row container
                      //

                      Container(
                        // height: 77,
                        padding: EdgeInsets.only(top: 25.2, left: 0, right: 10),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Stack(
                              children: [
                                Container(
                                    width: widthSize - 37,
                                    height: 82,
                                    padding: EdgeInsets.only(top: 10),
                                    margin: EdgeInsets.only(top: 50),
                                    decoration: BoxDecoration(
                                        color: Colors.white,
                                        border: Border.all(
                                          color: Colors.green,
                                          width: 0.7,
                                        ),
                                        borderRadius: BorderRadius.only(
                                          topRight: Radius.circular(13),
                                          topLeft: Radius.circular(13),
                                        ) //                 <--- border radius here
                                        ),

                                    //width: widthSize,
                                    child: Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text("عدد المفقودات النقدية"),
                                          Text("0",
                                              style: TextStyle(
                                                  fontSize: 22,
                                                  fontWeight: FontWeight.bold)),
                                        ],
                                      ),
                                    )),
                                Positioned(
                                  // right: 77,
                                  bottom: 52,
                                  left: 227,
                                  //  width: 77,
                                  // height: 77,
                                  child: Container(
                                    decoration: BoxDecoration(
                                        gradient: LinearGradient(
                                          begin: Alignment.topRight,
                                          end: Alignment.bottomLeft,
                                          colors: [
                                            Color(0xff09ae1f),
                                            Color(0xff079d1b),
                                          ],
                                        ),
                                        //color: Color(0xff3fa804),
                                        border: Border.all(
                                          color: Colors.grey,
                                          width: 0.7,
                                        ),
                                        borderRadius: BorderRadius.only(
                                          topRight: Radius.circular(27),
                                          topLeft: Radius.circular(27),
                                          bottomLeft: Radius.circular(27),
                                          bottomRight: Radius.circular(27),
                                        ),
                                        boxShadow: [
                                          BoxShadow(
                                              color: Colors.grey.shade600,
                                              spreadRadius: 1,
                                              blurRadius: 15)
                                        ] //                 <--- border radius here
                                        ),
                                    // color: Color(0xffa48482),
                                    child: Container(
                                        width: 77,
                                        height: 77,
                                        child: Icon(
                                          Icons.bar_chart,
                                          size: 37,
                                          color: Colors.white,
                                        )),
                                    //Image.asset(
                                    // "images/LightGreenAna.JPG")),
                                    //Icon(Icons.analytics,
                                    //  size: 75, color: Colors.white),
                                  ),
                                ),
                              ], // Stack Children ends here
                            ),
                          ],
                        ),
                      ),
                      // above is the end of the green image row container
                      // above is the end of the greeen image row container

                      Container(
                        // height: 77,
                        padding: EdgeInsets.only(top: 25.2, left: 0, right: 10),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Stack(
                              children: [
                                Container(
                                    width: widthSize - 37,
                                    height: 82,
                                    padding: EdgeInsets.only(top: 10),
                                    margin: EdgeInsets.only(top: 50),
                                    decoration: BoxDecoration(
                                        color: Colors.white,
                                        border: Border.all(
                                          color: Colors.green,
                                          width: 0.7,
                                        ),
                                        borderRadius: BorderRadius.only(
                                          topRight: Radius.circular(13),
                                          topLeft: Radius.circular(13),
                                        ) //                 <--- border radius here
                                        ),

                                    //width: widthSize,
                                    child: Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            "عدد المفقودات العينية",
                                          ),
                                          Text("0",
                                              style: TextStyle(
                                                  fontSize: 22,
                                                  fontWeight: FontWeight.bold)),
                                        ],
                                      ),
                                    )),
                                Positioned(
                                  // right: 77,
                                  bottom: 52,
                                  left: 227,
                                  //  width: 77,
                                  // height: 77,
                                  child: Container(
                                    decoration: BoxDecoration(
                                        //color: Color(0xff0583be),

                                        gradient: LinearGradient(
                                          begin: Alignment.topRight,
                                          end: Alignment.bottomLeft,
                                          colors: [
                                            Color(0xff82ccef),
                                            Color(0xff0b2c9a),
                                          ],
                                        ),
                                        border: Border.all(
                                          color: Color(0xffbff0fe),
                                          width: 0.7,
                                        ),
                                        borderRadius: BorderRadius.only(
                                          topRight: Radius.circular(27),
                                          topLeft: Radius.circular(27),
                                          bottomLeft: Radius.circular(27),
                                          bottomRight: Radius.circular(27),
                                        ),
                                        boxShadow: [
                                          BoxShadow(
                                              color: Colors.grey.shade600,
                                              spreadRadius: 1,
                                              blurRadius: 15)
                                        ] //                 <--- border radius here
                                        ),
                                    // color: Color(0xffa48482),
                                    child: Container(
                                        width: 77,
                                        height: 77,
                                        child: Icon(
                                          Icons.bar_chart,
                                          size: 37,
                                          color: Colors.white,
                                        )),

                                    // Image.asset("images/blueAna.JPG")),
                                    //Icon(Icons.analytics,
                                    //  size: 75, color: Colors.white),
                                  ),
                                ),
                              ], // Stack Children ends here
                            ),
                          ],
                        ),
                      ),
                      // above is the end of the last image row container
                      // above is the end of the last image row container
                      //
                      //

                      Container(
                        margin: EdgeInsets.only(top: 12),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: <Widget>[
                            Column(
                              children: [
                                Container(
                                  decoration: BoxDecoration(
                                      color: Colors.white,
                                      border: Border.all(
                                        color: Colors.grey,
                                        width: 0.7,
                                      ),
                                      borderRadius: BorderRadius.only(
                                        topRight: Radius.circular(13),
                                        topLeft: Radius.circular(13),
                                        bottomLeft: Radius.circular(13),
                                        bottomRight: Radius.circular(13),
                                      ) //                 <--- border radius here
                                      ),
                                  width: widthSize / 3 + 30,
                                  margin: EdgeInsets.only(right: 10),
                                  //  color: Colors.white,
                                  child: Stack(children: [
                                    Container(
                                      decoration: BoxDecoration(
                                          color: Colors.red,
                                          border: Border.all(
                                            color: Colors.white,
                                            width: 0,
                                          ),
                                          borderRadius: BorderRadius.only(
                                            topRight: Radius.circular(13),
                                            topLeft: Radius.circular(13),
                                            bottomLeft: Radius.circular(13),
                                            bottomRight: Radius.circular(13),
                                          ) //                 <--- border radius here
                                          ),
                                      margin: EdgeInsets.only(
                                          top: 22, left: 7, right: 7),
                                      // color: Colors.red,
                                      child: Column(
                                        children: [
                                          Container(
                                            width: 200,
                                            margin: EdgeInsets.only(top: 22),
                                            padding: EdgeInsets.only(
                                                top: 22,
                                                left: 7,
                                                right: 8,
                                                bottom: 7),
                                            color: Colors.red,
                                            child: Text("0.8______________",
                                                style: TextStyle(
                                                    color: Color(0xffcdcdcd))),
                                          ),
                                          Container(
                                            margin: EdgeInsets.only(top: 22),
                                            padding: EdgeInsets.only(
                                                top: 22,
                                                left: 7,
                                                right: 8,
                                                bottom: 7),
                                            color: Colors.red,
                                            child: Text(
                                                "0.4 _ _ _ _ _ _ _ _ _ _",
                                                style: TextStyle(
                                                    color: Color(0xffcdcdcd))),
                                          ),
                                          Container(
                                            margin: EdgeInsets.only(top: 22),
                                            padding: EdgeInsets.only(
                                                top: 22,
                                                left: 7,
                                                right: 8,
                                                bottom: 7),
                                            color: Colors.red,
                                            child: Text("0 _ _ _ _ _ _ _ _ _ _",
                                                style: TextStyle(
                                                    color: Color(0xffcdcdcd))),
                                          ),
                                          // Text("التحويلات النفدية")
                                          //
                                          Container(
                                            width: widthSize / 3 + 30,
                                            color: Colors.white,
                                            child: Column(
                                              children: [
                                                Text("  التحويلات  النقدية"),
                                                Container(
                                                  child:
                                                      Text("________________"),
                                                ),
                                                Container(
                                                  child: Row(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                      children: [
                                                        Text("تم تحديثه للتو"),
                                                        Icon(
                                                            Icons.update_sharp),
                                                      ]),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ]),
                                ),
                              ],
                            ),
                            SizedBox(width: 2),
                            Column(
                              children: [
                                Container(
                                  decoration: BoxDecoration(
                                      color: Colors.white,
                                      border: Border.all(
                                        color: Colors.grey,
                                        width: 0.7,
                                      ),
                                      borderRadius: BorderRadius.only(
                                        topRight: Radius.circular(13),
                                        topLeft: Radius.circular(13),
                                        //  bottomLeft: Radius.circular(13),
                                        //  bottomRight: Radius.circular(13),
                                      ) //                 <--- border radius here
                                      ),
                                  width: widthSize / 3 + 30,
                                  margin: EdgeInsets.only(right: 0, left: 0),
                                  //   color: Colors.white,
                                  child: Stack(children: [
                                    Container(
                                      // alignment: Alignment.center,
                                      // margin: EdgeInsets.only(right: 35, left: 35),
                                      //
                                      decoration: BoxDecoration(
                                          // color: Colors.red,
                                          color: Color(0xff078176),
                                          border: Border.all(
                                            color: Colors.white,
                                            width: 0,
                                          ),
                                          borderRadius: BorderRadius.only(
                                            topRight: Radius.circular(13),
                                            topLeft: Radius.circular(13),
                                            bottomLeft: Radius.circular(13),
                                            bottomRight: Radius.circular(13),
                                          ) //                 <--- border radius here
                                          ),

                                      margin: EdgeInsets.only(
                                          top: 22, right: 15, left: 15),
                                      // color: Color(0xff078176),
                                      //Colors.greenAccent,
                                      child: Column(
                                        children: [
                                          Container(
                                            width: 200,
                                            margin: EdgeInsets.only(top: 22),
                                            padding: EdgeInsets.only(
                                                top: 22,
                                                left: 7,
                                                right: 8,
                                                bottom: 7),
                                            color: Color(0xff078176),
                                            child: Text("07 _ _ _ _ _ _ _ _ _ ",
                                                style: TextStyle(
                                                    color: Color(0xffcdcdcd))),
                                          ),
                                          Container(
                                            margin: EdgeInsets.only(top: 22),
                                            padding: EdgeInsets.only(
                                                top: 22,
                                                left: 7,
                                                right: 8,
                                                bottom: 7),
                                            color: Colors.transparent,
                                            child: Text("0.4 _ _ _ _ _ _ _ _ ",
                                                style: TextStyle(
                                                    color: Color(0xffcdcdcd))),
                                          ),
                                          Container(
                                            margin: EdgeInsets.only(top: 22),
                                            padding: EdgeInsets.only(
                                                top: 22,
                                                left: 7,
                                                right: 8,
                                                bottom: 7),
                                            color: Colors.transparent,
                                            child: Text("0 _ _ _ _ _ _ _ _ _ ",
                                                style: TextStyle(
                                                    color: Color(0xffcdcdcd))),
                                          ),
                                          // Text("التحويلات النفدية")
                                        ],
                                      ),
                                    ),
                                  ]),
                                ),
                                Container(
                                  decoration: BoxDecoration(
                                      color: Colors.white,
                                      border: Border.all(
                                        color: Colors.white,
                                        width: 0.7,
                                      ),
                                      borderRadius: BorderRadius.only(
                                        //   topRight: Radius.circular(13),
                                        //  topLeft: Radius.circular(13),
                                        bottomLeft: Radius.circular(13),
                                        bottomRight: Radius.circular(13),
                                      ) //                 <--- border radius here
                                      ),
                                  width: widthSize / 3 + 30,
                                  //color: Colors.white,
                                  child: Column(
                                    children: [
                                      Text("المفقود حسب السنة"),
                                      Container(
                                        child: Text("________________"),
                                      ),
                                      Container(
                                        child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            children: [
                                              Text("تم تحديثه للتو"),
                                              Icon(Icons.update_sharp),
                                            ]),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),

                      Container(
                        margin: EdgeInsets.only(top: 27),
                        alignment: Alignment.center,
                        child: Text(
                            "  الهيئة العامة للولاية على أموال القاصرين ومن في حكمهم @"),
                      ),

                      Container(
                        margin: EdgeInsets.only(top: 2),
                        alignment: Alignment.center,
                        child: Text("  2022"),
                      ),
                      // the parent column ends below
                      // the parent column ends below
                    ]),
              ),
            ),
          ],
        ),
      ),

////////////////////////////////////////
// the endDrawer is below
///////////////////////////////////////
      endDrawer: Container(
        padding: EdgeInsets.only(top: 7, left: 7, right: 7),
        child: Drawer(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Image.asset("images/title.JPG"),
              Padding(
                padding: const EdgeInsets.only(top: 22.0, right: 52),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: <Widget>[
                    Text("الرئيسية", style: TextStyle(fontSize: 17)),
                    SizedBox(width: 12),
                    Image.asset("images/home.JPG"),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 22.0, right: 52),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: <Widget>[
                    Text("تسجيل المفقودات", style: TextStyle(fontSize: 17)),
                    SizedBox(width: 12),
                    Icon(Icons.person),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 22.0, right: 52),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: <Widget>[
                    Text(" للتواصل والدعم", style: TextStyle(fontSize: 17)),
                    SizedBox(width: 12),
                    Icon(Icons.person),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 22.0, right: 52),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: <Widget>[
                    Text(" دليل المستخدم", style: TextStyle(fontSize: 17)),
                    SizedBox(width: 12),
                    Icon(Icons.person),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 22.0, right: 52),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: <Widget>[
                    Text(" الأمر السامي", style: TextStyle(fontSize: 17)),
                    SizedBox(width: 12),
                    Icon(Icons.person),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 22.0, right: 52),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: <Widget>[
                    Text("تسجيل خروج", style: TextStyle(fontSize: 17)),
                    SizedBox(width: 12),
                    Icon(Icons.logout),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),

      // This trailing comma makes auto-formatting nicer for build methods.
    );
  }
}
